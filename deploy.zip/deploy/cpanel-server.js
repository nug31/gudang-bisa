import express from "express";
import mysql from "mysql2/promise";
import { config } from "dotenv";
import { v4 as uuidv4 } from "uuid";
import cors from "cors";
import bodyParser from "body-parser";
import bcrypt from "bcryptjs";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

// Load environment variables
config();

// Get the directory name
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 8080;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Serve static files from the dist directory
app.use(express.static(path.join(__dirname, "dist")));

// Create database connection pool
console.log("Creating database connection pool with the following settings:");
console.log(`Host: ${process.env.DB_HOST}`);
console.log(`Port: ${process.env.DB_PORT || 3306}`);
console.log(`User: ${process.env.DB_USER}`);
console.log(`Database: ${process.env.DB_NAME}`);

const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Test database connection
app.get("/api/test-connection", async (req, res) => {
  try {
    console.log("Testing database connection with settings:", {
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      database: process.env.DB_NAME,
      port: process.env.DB_PORT,
    });

    const connection = await pool.getConnection();
    console.log("Database connected successfully");

    // Test a simple query
    try {
      const [result] = await connection.query("SELECT 1 as test");
      console.log("Test query result:", result);
    } catch (queryError) {
      console.error("Error executing test query:", queryError);
    }

    connection.release();
    res.json({ success: true, message: "Database connected successfully" });
  } catch (error) {
    console.error("Error connecting to database:", error);
    res.status(500).json({
      success: false,
      message: "Error connecting to database",
      error: error.message,
    });
  }
});

// Login endpoint
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body;
  console.log("Login attempt:", { email });

  // Validate required fields
  if (!email || !password) {
    return res
      .status(400)
      .json({ message: "Email and password are required" });
  }

  try {
    const connection = await pool.getConnection();

    // Find user by email
    console.log(`Searching for user with email: ${email}`);
    const [users] = await connection.query(
      `SELECT
        id,
        name,
        email,
        password,
        role,
        department,
        avatar_url as avatarUrl,
        created_at as createdAt
      FROM users
      WHERE email = ?`,
      [email]
    );

    connection.release();

    if (users.length === 0) {
      console.log(`No user found with email: ${email}`);
      return res.status(401).json({ message: "Invalid email or password" });
    }

    const user = users[0];
    const storedPassword = user.password;
    console.log(`User found: ${user.name} (${user.email}), Role: ${user.role}`);

    // Compare passwords
    let isPasswordValid = false;
    
    // First try bcrypt compare
    try {
      isPasswordValid = await bcrypt.compare(password, storedPassword);
    } catch (bcryptError) {
      console.error("Error comparing passwords with bcrypt:", bcryptError);
      
      // If bcrypt fails, try direct comparison (for legacy passwords)
      isPasswordValid = password === storedPassword;
    }

    console.log(`Final password validation result: ${isPasswordValid}`);

    if (!isPasswordValid) {
      console.log("Password validation failed");
      return res.status(401).json({ message: "Invalid email or password" });
    }

    console.log(`Login successful for user: ${user.email}`);
    res.json({
      user: user,
      message: "Login successful",
    });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// Registration endpoint
app.post("/api/register", async (req, res) => {
  const { name, email, password, role, department } = req.body;
  console.log("Registration attempt:", { name, email, role, department });

  // Validate required fields
  if (!name || !email || !password || !role) {
    return res
      .status(400)
      .json({ message: "Name, email, password, and role are required" });
  }

  try {
    const connection = await pool.getConnection();

    // Check if user already exists
    const [existingUsers] = await connection.query(
      "SELECT * FROM users WHERE email = ?",
      [email]
    );

    if (existingUsers.length > 0) {
      connection.release();
      return res.status(400).json({ message: "Email already in use" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Generate a unique ID
    const userId = uuidv4();

    // Insert new user
    await connection.query(
      `INSERT INTO users (
        id, 
        name, 
        email, 
        password, 
        role, 
        department, 
        created_at
      ) VALUES (?, ?, ?, ?, ?, ?, NOW())`,
      [userId, name, email, hashedPassword, role, department || null]
    );

    connection.release();

    res.status(201).json({
      message: "User registered successfully",
      user: {
        id: userId,
        name,
        email,
        role,
        department,
      },
    });
  } catch (error) {
    console.error("Registration error:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
});

// Direct database access endpoint for requests
app.post("/db/requests", async (req, res) => {
  const { action, id, request, comment } = req.body;
  console.log(
    "Request body for /db/requests:",
    JSON.stringify(req.body, null, 2)
  );

  try {
    const connection = await pool.getConnection();

    switch (action) {
      case "getAll":
        const [requests] = await connection.query(
          `SELECT 
            r.id,
            r.user_id as userId,
            r.item_name as itemName,
            r.quantity,
            r.category,
            r.status,
            r.created_at as createdAt,
            r.updated_at as updatedAt,
            r.admin_comment as adminComment,
            u.name as userName,
            u.department as userDepartment
          FROM item_requests r
          LEFT JOIN users u ON r.user_id = u.id
          ORDER BY r.created_at DESC`
        );
        connection.release();
        res.json(requests);
        break;

      case "getById":
        const [requestById] = await connection.query(
          `SELECT 
            r.id,
            r.user_id as userId,
            r.item_name as itemName,
            r.quantity,
            r.category,
            r.status,
            r.created_at as createdAt,
            r.updated_at as updatedAt,
            r.admin_comment as adminComment,
            u.name as userName,
            u.department as userDepartment
          FROM item_requests r
          LEFT JOIN users u ON r.user_id = u.id
          WHERE r.id = ?`,
          [id]
        );
        connection.release();

        if (requestById.length === 0) {
          return res.status(404).json({ message: "Request not found" });
        }

        res.json(requestById[0]);
        break;

      case "create":
        const requestId = uuidv4();
        const now = new Date().toISOString().slice(0, 19).replace("T", " ");

        await connection.query(
          `INSERT INTO item_requests (
            id, 
            user_id, 
            item_name, 
            quantity, 
            category, 
            status, 
            created_at, 
            updated_at
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            requestId,
            request.userId,
            request.itemName,
            request.quantity,
            request.category,
            "pending",
            now,
            now,
          ]
        );

        // Get the created request
        const [createdRequest] = await connection.query(
          `SELECT 
            r.id,
            r.user_id as userId,
            r.item_name as itemName,
            r.quantity,
            r.category,
            r.status,
            r.created_at as createdAt,
            r.updated_at as updatedAt,
            r.admin_comment as adminComment,
            u.name as userName,
            u.department as userDepartment
          FROM item_requests r
          LEFT JOIN users u ON r.user_id = u.id
          WHERE r.id = ?`,
          [requestId]
        );

        connection.release();
        res.status(201).json(createdRequest[0]);
        break;

      case "update":
        const updateNow = new Date().toISOString().slice(0, 19).replace("T", " ");

        await connection.query(
          `UPDATE item_requests SET 
            item_name = ?, 
            quantity = ?, 
            category = ?, 
            status = ?, 
            updated_at = ?,
            admin_comment = ?
          WHERE id = ?`,
          [
            request.itemName,
            request.quantity,
            request.category,
            request.status,
            updateNow,
            request.adminComment || null,
            request.id,
          ]
        );

        // Get the updated request
        const [updatedRequest] = await connection.query(
          `SELECT 
            r.id,
            r.user_id as userId,
            r.item_name as itemName,
            r.quantity,
            r.category,
            r.status,
            r.created_at as createdAt,
            r.updated_at as updatedAt,
            r.admin_comment as adminComment,
            u.name as userName,
            u.department as userDepartment
          FROM item_requests r
          LEFT JOIN users u ON r.user_id = u.id
          WHERE r.id = ?`,
          [request.id]
        );

        connection.release();
        res.json(updatedRequest[0]);
        break;

      case "delete":
        await connection.query("DELETE FROM item_requests WHERE id = ?", [id]);
        connection.release();
        res.json({ message: "Request deleted successfully" });
        break;

      case "addComment":
        await connection.query(
          `UPDATE item_requests SET 
            admin_comment = ?, 
            updated_at = NOW()
          WHERE id = ?`,
          [comment, id]
        );
        connection.release();
        res.json({ message: "Comment added successfully" });
        break;

      default:
        connection.release();
        res.status(400).json({ message: "Invalid action" });
    }
  } catch (error) {
    console.error("Error executing database operation:", error);
    console.error("Error code:", error.code);
    console.error("Error message:", error.message);
    console.error("SQL state:", error.sqlState);
    console.error("SQL message:", error.sqlMessage);

    // Check if it's an access denied error
    if (error.code === "ER_ACCESS_DENIED_ERROR") {
      console.error("Access denied error. Check your database credentials.");
      console.error("Attempted connection with:");
      console.error(`Host: ${process.env.DB_HOST}`);
      console.error(`User: ${process.env.DB_USER}`);
      console.error(`Database: ${process.env.DB_NAME}`);
      console.error(`Port: ${process.env.DB_PORT}`);
    }

    res.status(500).json({
      message: "Database error",
      error: error.message,
      code: error.code,
      sqlState: error.sqlState,
    });
  }
});

// Handle users requests
app.post("/db/users", async (req, res) => {
  const { action, id, user } = req.body;
  console.log("Users request body:", req.body);

  try {
    const connection = await pool.getConnection();

    switch (action) {
      case "getAll":
        const [users] = await connection.query(
          `SELECT 
            id, 
            name, 
            email, 
            role, 
            department, 
            avatar_url as avatarUrl, 
            created_at as createdAt 
          FROM users 
          ORDER BY created_at DESC`
        );
        connection.release();
        res.json(users);
        break;

      case "getById":
        const [userById] = await connection.query(
          `SELECT 
            id, 
            name, 
            email, 
            role, 
            department, 
            avatar_url as avatarUrl, 
            created_at as createdAt 
          FROM users 
          WHERE id = ?`,
          [id]
        );
        connection.release();

        if (userById.length === 0) {
          return res.status(404).json({ message: "User not found" });
        }

        res.json(userById[0]);
        break;

      case "update":
        await connection.query(
          `UPDATE users SET 
            name = ?, 
            email = ?, 
            role = ?, 
            department = ?, 
            avatar_url = ? 
          WHERE id = ?`,
          [
            user.name,
            user.email,
            user.role,
            user.department || null,
            user.avatarUrl || null,
            user.id,
          ]
        );

        // Get the updated user
        const [updatedUser] = await connection.query(
          `SELECT 
            id, 
            name, 
            email, 
            role, 
            department, 
            avatar_url as avatarUrl, 
            created_at as createdAt 
          FROM users 
          WHERE id = ?`,
          [user.id]
        );

        connection.release();
        res.json(updatedUser[0]);
        break;

      case "delete":
        await connection.query("DELETE FROM users WHERE id = ?", [id]);
        connection.release();
        res.json({ message: "User deleted successfully" });
        break;

      default:
        connection.release();
        res.status(400).json({ message: "Invalid action" });
    }
  } catch (error) {
    console.error("Error executing database operation:", error);
    res.status(500).json({ message: "Database error", error: error.message });
  }
});

// Catch-all route to serve the frontend
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "dist", "index.html"));
});

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Visit http://localhost:${PORT} to access the application`);
});

export default app;
