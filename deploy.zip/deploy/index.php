<?php
// Simple index.php to serve the SPA application
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Log errors to a file
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/php_errors.log');

// Add CORS headers to allow requests from any origin
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight OPTIONS requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Define the path to the dist directory
$dist_path = __DIR__ . '/dist';

// Log some debug information
$debug_log = fopen(__DIR__ . '/debug.log', 'a');
fwrite($debug_log, "Request at " . date('Y-m-d H:i:s') . "\n");
fwrite($debug_log, "Request URI: " . $_SERVER['REQUEST_URI'] . "\n");
fwrite($debug_log, "Dist path: " . $dist_path . "\n");

// Get the requested URI
$request_uri = $_SERVER['REQUEST_URI'];
$request_path = parse_url($request_uri, PHP_URL_PATH);

// Remove leading slash and any query parameters
$clean_path = ltrim($request_path, '/');
if (empty($clean_path)) {
    // If the path is empty, serve the index.html
    $file_path = $dist_path . '/index.html';
} else {
    $file_path = $dist_path . '/' . $clean_path;
}

fwrite($debug_log, "Clean path: " . $clean_path . "\n");
fwrite($debug_log, "File path: " . $file_path . "\n");

// Check if this is an API request
if (strpos($request_path, '/api/') === 0 || strpos($request_path, '/db/') === 0) {
    fwrite($debug_log, "API request detected: " . $request_path . "\n");

    // This is an API request, handle it with mock data
    header('Content-Type: application/json');

    // Handle login requests
    if ($request_path === '/api/login' || $request_path === '/api/test-connection') {
        fwrite($debug_log, "Login request detected\n");

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $input = json_decode(file_get_contents('php://input'), true);
            $email = $input['email'] ?? '';
            $password = $input['password'] ?? '';

            fwrite($debug_log, "Login attempt: " . $email . "\n");

            // Simple validation
            if ($email === 'admin@gudangmitra.com' && $password === 'admin123') {
                echo json_encode([
                    'user' => [
                        'id' => '1',
                        'name' => 'Admin',
                        'email' => 'admin@gudangmitra.com',
                        'role' => 'admin',
                        'department' => 'Management',
                        'avatarUrl' => null,
                        'createdAt' => date('Y-m-d H:i:s')
                    ],
                    'message' => 'Login successful'
                ]);
            } else {
                http_response_code(401);
                echo json_encode(['message' => 'Invalid email or password']);
            }
        } else {
            echo json_encode(['success' => true, 'message' => 'Mock API is working']);
        }
    }
    // Handle requests data
    elseif (strpos($request_path, '/db/requests') === 0) {
        fwrite($debug_log, "Requests data requested\n");

        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';

        fwrite($debug_log, "Action: " . $action . "\n");

        if ($action === 'getAll') {
            echo json_encode([
                [
                    'id' => '1',
                    'userId' => '1',
                    'itemName' => 'Printer Paper',
                    'quantity' => 5,
                    'category' => 'Office',
                    'status' => 'pending',
                    'createdAt' => date('Y-m-d H:i:s'),
                    'updatedAt' => date('Y-m-d H:i:s'),
                    'adminComment' => null,
                    'userName' => 'Admin',
                    'userDepartment' => 'Management'
                ],
                [
                    'id' => '2',
                    'userId' => '1',
                    'itemName' => 'Whiteboard Markers',
                    'quantity' => 10,
                    'category' => 'Office',
                    'status' => 'approved',
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-1 day')),
                    'updatedAt' => date('Y-m-d H:i:s'),
                    'adminComment' => 'Approved',
                    'userName' => 'Admin',
                    'userDepartment' => 'Management'
                ],
                [
                    'id' => '3',
                    'userId' => '2',
                    'itemName' => 'Cleaning Supplies',
                    'quantity' => 3,
                    'category' => 'Cleaning',
                    'status' => 'rejected',
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-2 days')),
                    'updatedAt' => date('Y-m-d H:i:s'),
                    'adminComment' => 'Out of stock',
                    'userName' => 'Manager',
                    'userDepartment' => 'Facilities'
                ],
                [
                    'id' => '4',
                    'userId' => '3',
                    'itemName' => 'Laptop Charger',
                    'quantity' => 1,
                    'category' => 'Hardware',
                    'status' => 'pending',
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-3 hours')),
                    'updatedAt' => date('Y-m-d H:i:s'),
                    'adminComment' => null,
                    'userName' => 'User',
                    'userDepartment' => 'IT'
                ]
            ]);
        } elseif ($action === 'create') {
            $request = $input['request'] ?? [];
            $newRequest = [
                'id' => uniqid(),
                'userId' => $request['userId'] ?? '1',
                'itemName' => $request['itemName'] ?? '',
                'quantity' => $request['quantity'] ?? 0,
                'category' => $request['category'] ?? '',
                'status' => 'pending',
                'createdAt' => date('Y-m-d H:i:s'),
                'updatedAt' => date('Y-m-d H:i:s'),
                'adminComment' => null,
                'userName' => 'Admin',
                'userDepartment' => 'Management'
            ];
            echo json_encode($newRequest);
        } elseif ($action === 'update') {
            $request = $input['request'] ?? [];
            $request['updatedAt'] = date('Y-m-d H:i:s');
            echo json_encode($request);
        } else {
            echo json_encode(['message' => 'Action not supported in mock mode']);
        }
    }
    // Handle users data
    elseif (strpos($request_path, '/db/users') === 0) {
        fwrite($debug_log, "Users data requested\n");

        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';

        fwrite($debug_log, "Action: " . $action . "\n");

        if ($action === 'getAll') {
            echo json_encode([
                [
                    'id' => '1',
                    'name' => 'Admin',
                    'email' => 'admin@gudangmitra.com',
                    'role' => 'admin',
                    'department' => 'Management',
                    'avatarUrl' => null,
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-7 days'))
                ],
                [
                    'id' => '2',
                    'name' => 'Manager',
                    'email' => 'manager@gudangmitra.com',
                    'role' => 'manager',
                    'department' => 'Facilities',
                    'avatarUrl' => null,
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-5 days'))
                ],
                [
                    'id' => '3',
                    'name' => 'User',
                    'email' => 'user@gudangmitra.com',
                    'role' => 'user',
                    'department' => 'IT',
                    'avatarUrl' => null,
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-3 days'))
                ]
            ]);
        } elseif ($action === 'create') {
            $user = $input['user'] ?? [];
            $newUser = [
                'id' => uniqid(),
                'name' => $user['name'] ?? '',
                'email' => $user['email'] ?? '',
                'role' => $user['role'] ?? 'user',
                'department' => $user['department'] ?? null,
                'avatarUrl' => null,
                'createdAt' => date('Y-m-d H:i:s')
            ];
            echo json_encode($newUser);
        } elseif ($action === 'update') {
            $user = $input['user'] ?? [];
            echo json_encode($user);
        } else {
            echo json_encode(['message' => 'Action not supported in mock mode']);
        }
    }
    // Handle inventory data
    elseif (strpos($request_path, '/db/inventory') === 0) {
        fwrite($debug_log, "Inventory data requested\n");

        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';

        fwrite($debug_log, "Action: " . $action . "\n");

        if ($action === 'getAll') {
            echo json_encode([
                [
                    'id' => '1',
                    'itemName' => 'Printer Paper',
                    'quantity' => 50,
                    'category' => 'Office',
                    'location' => 'Warehouse A',
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-30 days')),
                    'updatedAt' => date('Y-m-d H:i:s', strtotime('-5 days'))
                ],
                [
                    'id' => '2',
                    'itemName' => 'Whiteboard Markers',
                    'quantity' => 100,
                    'category' => 'Office',
                    'location' => 'Warehouse A',
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-25 days')),
                    'updatedAt' => date('Y-m-d H:i:s', strtotime('-3 days'))
                ],
                [
                    'id' => '3',
                    'itemName' => 'Cleaning Supplies',
                    'quantity' => 20,
                    'category' => 'Cleaning',
                    'location' => 'Warehouse B',
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-20 days')),
                    'updatedAt' => date('Y-m-d H:i:s', strtotime('-2 days'))
                ],
                [
                    'id' => '4',
                    'itemName' => 'Laptop Charger',
                    'quantity' => 15,
                    'category' => 'Hardware',
                    'location' => 'Warehouse C',
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-15 days')),
                    'updatedAt' => date('Y-m-d H:i:s', strtotime('-1 day'))
                ]
            ]);
        } elseif ($action === 'create') {
            $item = $input['item'] ?? [];
            $newItem = [
                'id' => uniqid(),
                'itemName' => $item['itemName'] ?? '',
                'quantity' => $item['quantity'] ?? 0,
                'category' => $item['category'] ?? '',
                'location' => $item['location'] ?? '',
                'createdAt' => date('Y-m-d H:i:s'),
                'updatedAt' => date('Y-m-d H:i:s')
            ];
            echo json_encode($newItem);
        } elseif ($action === 'update') {
            $item = $input['item'] ?? [];
            $item['updatedAt'] = date('Y-m-d H:i:s');
            echo json_encode($item);
        } else {
            echo json_encode(['message' => 'Action not supported in mock mode']);
        }
    }
    // Handle notifications data
    elseif (strpos($request_path, '/db/notifications') === 0) {
        fwrite($debug_log, "Notifications data requested\n");

        $input = json_decode(file_get_contents('php://input'), true);
        $action = $input['action'] ?? '';

        fwrite($debug_log, "Action: " . $action . "\n");

        if ($action === 'getAll') {
            echo json_encode([
                [
                    'id' => '1',
                    'userId' => '1',
                    'message' => 'New inventory request from User',
                    'read' => false,
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-3 hours')),
                    'type' => 'request'
                ],
                [
                    'id' => '2',
                    'userId' => '1',
                    'message' => 'Your request for Whiteboard Markers has been approved',
                    'read' => true,
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-1 day')),
                    'type' => 'approval'
                ],
                [
                    'id' => '3',
                    'userId' => '1',
                    'message' => 'Low stock alert: Cleaning Supplies',
                    'read' => false,
                    'createdAt' => date('Y-m-d H:i:s', strtotime('-2 days')),
                    'type' => 'alert'
                ]
            ]);
        } elseif ($action === 'markAsRead') {
            $notificationId = $input['notificationId'] ?? '';
            echo json_encode(['success' => true, 'message' => 'Notification marked as read']);
        } else {
            echo json_encode(['message' => 'Action not supported in mock mode']);
        }
    }
    // Default API response for any other endpoints
    else {
        fwrite($debug_log, "Unknown API endpoint: " . $request_path . "\n");
        echo json_encode([
            'success' => true,
            'message' => 'Mock API response for ' . $request_path,
            'data' => [
                'user' => [
                    'id' => '1',
                    'name' => 'Admin',
                    'email' => 'admin@gudangmitra.com',
                    'role' => 'admin',
                    'department' => 'Management'
                ]
            ]
        ]);
    }

    fwrite($debug_log, "API response sent\n");
    fclose($debug_log);
    exit;
}

// If the file exists, serve it
if (file_exists($file_path)) {
    fwrite($debug_log, "File exists, serving: " . $file_path . "\n");

    // Determine the content type based on file extension
    $extension = pathinfo($file_path, PATHINFO_EXTENSION);
    $content_types = [
        'html' => 'text/html',
        'css' => 'text/css',
        'js' => 'application/javascript',
        'json' => 'application/json',
        'png' => 'image/png',
        'jpg' => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'gif' => 'image/gif',
        'svg' => 'image/svg+xml',
        'ico' => 'image/x-icon'
    ];

    $content_type = $content_types[$extension] ?? 'application/octet-stream';
    header("Content-Type: $content_type");
    readfile($file_path);

    fclose($debug_log);
    exit;
}

// If the file doesn't exist, serve the index.html (for SPA routing)
$index_path = $dist_path . '/index.html';
if (file_exists($index_path)) {
    fwrite($debug_log, "File not found, serving index.html instead\n");
    header('Content-Type: text/html');
    readfile($index_path);

    fclose($debug_log);
    exit;
}

// If we get here, something went wrong
fwrite($debug_log, "Error: Neither requested file nor index.html found\n");
http_response_code(404);
echo "404 Not Found - Neither the requested file nor index.html could be found.";
fclose($debug_log);
?>
