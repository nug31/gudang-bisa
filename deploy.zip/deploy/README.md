# Gudang Mitra cPanel Deployment

## Deployment Instructions

1. Upload all files in this directory to your cPanel account at: gudang.nugjo.com

2. Run the proxy-fix.php script to update the JavaScript files:

   - Visit http://gudang.nugjo.com/proxy-fix.php in your browser
   - This will modify the JavaScript files to use relative URLs instead of localhost
   - It will also update the database connection settings to use your cPanel database

3. Make sure your database is set up correctly:

   - The database should be named: oyishhkx_gudang
   - The database user should be: oyishhkx_gudang
   - The password is set in the .env file

4. Visit your website to verify the deployment:
   - Go to http://gudang.nugjo.com
   - Log in with the default admin credentials:
     - Email: admin@gudangmitra.com
     - Password: admin123

## How This Works

This deployment uses two possible approaches:

### 1. Node.js Approach (Recommended if your cPanel supports Node.js)

- Uses the cpanel-server.js file to handle API requests and serve the frontend
- Connects to a real MySQL database
- Provides full functionality

### 2. PHP Fallback Approach (If Node.js is not available)

- Uses index.php to serve the frontend and provide mock API responses
- No database setup required
- Limited functionality but works for demonstration

## Troubleshooting

If you encounter any issues:

1. Check if your cPanel supports Node.js:

   - If yes, use the Node.js approach
   - If no, use the PHP fallback approach

2. Database connection issues:

   - Verify your database credentials in the .env file
   - Make sure the database and user exist in cPanel
   - Check if the database user has the necessary permissions

3. CORS or API issues:

   - Run the proxy-fix.php script to update the JavaScript files
   - This will fix issues with localhost URLs and database connections

4. If all else fails:
   - Try the direct-login.html page for a simplified login experience
   - Try the simple.html page for a simplified version of the application

## Additional Information

### PHP Fallback Details

The PHP fallback approach uses index.php to:

1. Serve static files from the dist directory
2. Provide mock API responses for the application
3. Handle routing for the single-page application

This allows the application to run on standard PHP hosting without requiring Node.js support.

### Login Credentials

Use these credentials to log in:

- Email: admin@gudangmitra.com
- Password: admin123
