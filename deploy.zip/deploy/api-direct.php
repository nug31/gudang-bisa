<?php
// Direct API endpoint test
// This file directly outputs mock data without any routing or processing

// Set headers
header('Content-Type: application/json');

// Get the requested endpoint from the query parameter
$endpoint = $_GET['endpoint'] ?? 'login';

// Return mock data based on the requested endpoint
switch ($endpoint) {
    case 'login':
        echo json_encode([
            'user' => [
                'id' => '1',
                'name' => 'Admin',
                'email' => 'admin@gudangmitra.com',
                'role' => 'admin',
                'department' => 'Management',
                'avatarUrl' => null,
                'createdAt' => date('Y-m-d H:i:s')
            ],
            'message' => 'Login successful'
        ]);
        break;
        
    case 'requests':
        echo json_encode([
            [
                'id' => '1',
                'userId' => '1',
                'itemName' => 'Printer Paper',
                'quantity' => 5,
                'category' => 'Office',
                'status' => 'pending',
                'createdAt' => date('Y-m-d H:i:s'),
                'updatedAt' => date('Y-m-d H:i:s'),
                'adminComment' => null,
                'userName' => 'Admin',
                'userDepartment' => 'Management'
            ],
            [
                'id' => '2',
                'userId' => '1',
                'itemName' => 'Whiteboard Markers',
                'quantity' => 10,
                'category' => 'Office',
                'status' => 'approved',
                'createdAt' => date('Y-m-d H:i:s', strtotime('-1 day')),
                'updatedAt' => date('Y-m-d H:i:s'),
                'adminComment' => 'Approved',
                'userName' => 'Admin',
                'userDepartment' => 'Management'
            ]
        ]);
        break;
        
    case 'users':
        echo json_encode([
            [
                'id' => '1',
                'name' => 'Admin',
                'email' => 'admin@gudangmitra.com',
                'role' => 'admin',
                'department' => 'Management',
                'avatarUrl' => null,
                'createdAt' => date('Y-m-d H:i:s', strtotime('-7 days'))
            ],
            [
                'id' => '2',
                'name' => 'Manager',
                'email' => 'manager@gudangmitra.com',
                'role' => 'manager',
                'department' => 'Facilities',
                'avatarUrl' => null,
                'createdAt' => date('Y-m-d H:i:s', strtotime('-5 days'))
            ]
        ]);
        break;
        
    case 'inventory':
        echo json_encode([
            [
                'id' => '1',
                'itemName' => 'Printer Paper',
                'quantity' => 50,
                'category' => 'Office',
                'location' => 'Warehouse A',
                'createdAt' => date('Y-m-d H:i:s', strtotime('-30 days')),
                'updatedAt' => date('Y-m-d H:i:s', strtotime('-5 days'))
            ],
            [
                'id' => '2',
                'itemName' => 'Whiteboard Markers',
                'quantity' => 100,
                'category' => 'Office',
                'location' => 'Warehouse A',
                'createdAt' => date('Y-m-d H:i:s', strtotime('-25 days')),
                'updatedAt' => date('Y-m-d H:i:s', strtotime('-3 days'))
            ]
        ]);
        break;
        
    case 'notifications':
        echo json_encode([
            [
                'id' => '1',
                'userId' => '1',
                'message' => 'New inventory request from User',
                'read' => false,
                'createdAt' => date('Y-m-d H:i:s', strtotime('-3 hours')),
                'type' => 'request'
            ],
            [
                'id' => '2',
                'userId' => '1',
                'message' => 'Your request for Whiteboard Markers has been approved',
                'read' => true,
                'createdAt' => date('Y-m-d H:i:s', strtotime('-1 day')),
                'type' => 'approval'
            ]
        ]);
        break;
        
    default:
        echo json_encode([
            'success' => true,
            'message' => 'Unknown endpoint: ' . $endpoint
        ]);
        break;
}
?>
