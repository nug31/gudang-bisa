<?php
// Display all PHP information
phpinfo();
?>
