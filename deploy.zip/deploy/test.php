<?php
// Simple test script to verify PHP is working
echo "<html><head><title>Gudang Mitra PHP Test</title>";
echo "<style>body { font-family: Arial, sans-serif; margin: 40px; line-height: 1.6; }";
echo "h1 { color: #0066cc; } .success { color: green; } .info { color: #0066cc; }</style>";
echo "</head><body>";
echo "<h1>Gudang Mitra PHP Test</h1>";
echo "<p class='success'>✅ PHP is working correctly!</p>";

// Check if the dist directory exists
$dist_path = __DIR__ . '/dist';
if (is_dir($dist_path)) {
    echo "<p class='success'>✅ The dist directory exists.</p>";
    
    // Check if index.html exists
    $index_path = $dist_path . '/index.html';
    if (file_exists($index_path)) {
        echo "<p class='success'>✅ The index.html file exists.</p>";
    } else {
        echo "<p style='color:red'>❌ The index.html file is missing!</p>";
    }
    
    // List some files in the dist directory
    echo "<p class='info'>Files in the dist directory:</p><ul>";
    $files = scandir($dist_path);
    $count = 0;
    foreach ($files as $file) {
        if ($file != "." && $file != "..") {
            echo "<li>$file</li>";
            $count++;
            if ($count >= 10) {
                echo "<li>... and more</li>";
                break;
            }
        }
    }
    echo "</ul>";
} else {
    echo "<p style='color:red'>❌ The dist directory is missing!</p>";
}

// Check if .htaccess exists
if (file_exists(__DIR__ . '/.htaccess')) {
    echo "<p class='success'>✅ The .htaccess file exists.</p>";
} else {
    echo "<p style='color:red'>❌ The .htaccess file is missing!</p>";
}

// Check if index.php exists
if (file_exists(__DIR__ . '/index.php')) {
    echo "<p class='success'>✅ The index.php file exists.</p>";
} else {
    echo "<p style='color:red'>❌ The index.php file is missing!</p>";
}

// PHP info
echo "<p class='info'>PHP Version: " . phpversion() . "</p>";
echo "<p class='info'>Server Software: " . $_SERVER['SERVER_SOFTWARE'] . "</p>";

echo "<p>If all checks passed, your Gudang Mitra application should be working correctly.</p>";
echo "<p>Try accessing the main application at: <a href='./'>Gudang Mitra Application</a></p>";

echo "</body></html>";
?>
