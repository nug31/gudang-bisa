# Gudang Mitra cPanel Deployment Guide

This guide will walk you through the process of deploying the Gudang Mitra application to your cPanel hosting account.

## Prerequisites

1. A cPanel hosting account with:
   - Node.js support (via Node.js Selector or Application Manager)
   - MySQL database access
   - SSH access (recommended but not required)

2. Your database credentials:
   - Database name: `oyishhkx_gudang`
   - Database user: `oyishhkx_gudang`
   - Database password: `Reddevils94_08`

## Step 1: Test the cPanel Database Connection

Before deploying, test if you can connect to the cPanel database from your local machine:

```bash
node scripts/test-cpanel-connection.js
```

If the connection is successful, you'll see a list of tables in your database. If not, you may need to whitelist your IP address in cPanel.

## Step 2: Prepare Your Application for Deployment

Run the deployment preparation script:

```bash
node scripts/deploy-to-cpanel.js
```

This will:
1. Build your application
2. Create a `deploy` directory with all the files needed for deployment
3. Configure the application for cPanel

## Step 3: Set Up the Database in cPanel

1. Log in to your cPanel account
2. Navigate to "MySQL Databases"
3. If the database `oyishhkx_gudang` doesn't exist:
   - Create a new database named `gudang` (cPanel will prefix it with your username)
4. If the user `oyishhkx_gudang` doesn't exist:
   - Create a new user named `gudang` with the password `Reddevils94_08`
5. Add the user to the database with "All Privileges"

## Step 4: Initialize the Database Schema

1. In cPanel, go to "phpMyAdmin"
2. Select the `oyishhkx_gudang` database
3. Go to the "SQL" tab
4. Execute the following SQL to create the necessary tables:

```sql
-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('user', 'admin', 'manager') NOT NULL DEFAULT 'user',
  department VARCHAR(255),
  avatar_url VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create item_requests table
CREATE TABLE IF NOT EXISTS item_requests (
  id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  item_name VARCHAR(255) NOT NULL,
  quantity INT NOT NULL,
  category VARCHAR(255) NOT NULL,
  status ENUM('pending', 'approved', 'rejected', 'completed') NOT NULL DEFAULT 'pending',
  admin_comment TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id VARCHAR(36) PRIMARY KEY,
  user_id VARCHAR(36) NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create comments table
CREATE TABLE IF NOT EXISTS comments (
  id VARCHAR(36) PRIMARY KEY,
  request_id VARCHAR(36) NOT NULL,
  user_id VARCHAR(36) NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (request_id) REFERENCES item_requests(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create categories table
CREATE TABLE IF NOT EXISTS categories (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(255) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create inventory_items table
CREATE TABLE IF NOT EXISTS inventory_items (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  category_id VARCHAR(36) NOT NULL,
  quantity INT NOT NULL DEFAULT 0,
  unit VARCHAR(50),
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE
);

-- Insert default categories
INSERT INTO categories (id, name) VALUES 
  (UUID(), 'Office'),
  (UUID(), 'Cleaning Materials'),
  (UUID(), 'Hardware'),
  (UUID(), 'Other');

-- Insert default admin user
INSERT INTO users (id, name, email, password, role) VALUES 
  (UUID(), 'Admin', 'admin@gudangmitra.com', '$2a$10$eCc/ZVa9Vq6Ff.ZVwqZ9QOQz5.WQVm8K9XY9OFEfbLUcnF8pQUxpi', 'admin');
```

## Step 5: Upload Files to cPanel

### Option 1: Using File Manager

1. In cPanel, go to "File Manager"
2. Navigate to `public_html` (or where you want to deploy the application)
3. Create a new folder named `gudang-mitra`
4. Upload all files from the `deploy` directory to this folder

### Option 2: Using FTP

1. Use an FTP client (like FileZilla) to connect to your cPanel account
2. Navigate to `public_html` (or where you want to deploy the application)
3. Create a new folder named `gudang-mitra`
4. Upload all files from the `deploy` directory to this folder

## Step 6: Set Up Node.js Application in cPanel

1. In cPanel, go to "Setup Node.js App" or "Application Manager"
2. Click "Create Application"
3. Fill in the following details:
   - Node.js version: 18.x or higher
   - Application mode: Production
   - Application root: `/public_html/gudang-mitra` (adjust if needed)
   - Application URL: Your domain or subdomain
   - Application startup file: `cpanel-server.js`
   - Environment variables: (These should already be in your .env file)
4. Click "Create" to set up the Node.js application

## Step 7: Install Dependencies and Start the Application

1. If your cPanel provides SSH access:
   ```bash
   cd public_html/gudang-mitra
   npm install
   npm start
   ```

2. If SSH access is not available, you can use the Node.js Application Manager in cPanel to:
   - Install dependencies
   - Start the application

## Step 8: Configure Apache with .htaccess

The `.htaccess` file should already be in your deployment package. Make sure it's in your application's root directory.

## Step 9: Test Your Deployment

1. Visit your domain or subdomain in a web browser
2. Try logging in with the default admin credentials:
   - Email: admin@gudangmitra.com
   - Password: admin123

## Troubleshooting

### Database Connection Issues

If you encounter database connection issues:

1. Check that your database credentials are correct in the `.env` file
2. Verify that the database and user exist in cPanel
3. Make sure the user has the necessary privileges for the database
4. Try changing `DB_HOST` from `localhost` to `127.0.0.1` or your cPanel's MySQL hostname

### Node.js Application Issues

If the Node.js application doesn't start:

1. Check the application logs in the Node.js Application Manager
2. Make sure the Node.js version is compatible (18.x or higher)
3. Verify that all dependencies are installed correctly
4. Check that the `cpanel-server.js` file exists in the correct location

### Apache Configuration Issues

If you're having issues with the Apache configuration:

1. Make sure the `.htaccess` file is in the correct location
2. Check that mod_rewrite is enabled on your server
3. Verify that the proxy settings are correct for your server

## Additional Notes

- The default admin password is `admin123`
- You can create additional users through the application once it's deployed
- Make sure to update the admin password after your first login
