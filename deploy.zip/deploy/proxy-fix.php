<?php
// This script fixes the CORS and API endpoint issues by:
// 1. Adding CORS headers to allow requests from any origin
// 2. Modifying the JavaScript in index.html to use relative URLs instead of localhost

// Define the path to the dist directory
$dist_path = __DIR__ . '/dist';
$index_path = $dist_path . '/index.html';

// Check if index.html exists
if (file_exists($index_path)) {
    // Read the content of index.html
    $content = file_get_contents($index_path);

    // Look for JavaScript files
    preg_match_all('/<script[^>]*src="([^"]*)"[^>]*><\/script>/', $content, $matches);

    // Create a log file
    $log = fopen(__DIR__ . '/proxy-fix.log', 'w');
    fwrite($log, "Starting proxy fix at " . date('Y-m-d H:i:s') . "\n");
    fwrite($log, "Found " . count($matches[1]) . " script tags\n");

    // Process each JavaScript file
    foreach ($matches[1] as $script_src) {
        // Get the full path to the JavaScript file
        $script_path = $dist_path . '/' . ltrim($script_src, '/');

        fwrite($log, "Processing script: $script_src\n");
        fwrite($log, "Script path: $script_path\n");

        if (file_exists($script_path)) {
            // Read the content of the JavaScript file
            $script_content = file_get_contents($script_path);

            // Replace localhost URLs with relative URLs
            $original_content = $script_content;

            // Replace localhost:3001 with relative URLs
            $script_content = preg_replace('/http:\/\/localhost:3001\/api\//i', '/api/', $script_content);
            $script_content = preg_replace('/http:\/\/localhost:3001\/db\//i', '/db/', $script_content);
            $script_content = str_replace('localhost:3001', '', $script_content);

            // Replace database connection settings
            // Look for database connection configuration
            $script_content = str_replace('localhost', 'localhost', $script_content); // Keep localhost as is for now
            $script_content = str_replace('root', 'oyishhkx_gudang', $script_content); // Replace username
            $script_content = str_replace('password: ""', 'password: "Reddevils94_08"', $script_content); // Replace empty password
            $script_content = str_replace('password: \'\'', 'password: \'Reddevils94_08\'', $script_content); // Replace empty password (single quotes)
            $script_content = str_replace('gudang1', 'oyishhkx_gudang', $script_content); // Replace database name
            $script_content = str_replace('gudang', 'oyishhkx_gudang', $script_content); // Replace database name

            // Check if any replacements were made
            if ($script_content !== $original_content) {
                // Write the modified content back to the file
                file_put_contents($script_path, $script_content);
                fwrite($log, "Modified script: $script_src\n");
            } else {
                fwrite($log, "No changes needed for: $script_src\n");
            }
        } else {
            fwrite($log, "Script file not found: $script_path\n");
        }
    }

    // Also check for hardcoded localhost URLs in the index.html file
    $original_content = $content;
    $content = preg_replace('/http:\/\/localhost:3001\/api\//i', '/api/', $content);
    $content = preg_replace('/http:\/\/localhost:3001\/db\//i', '/db/', $content);
    $content = str_replace('localhost:3001', '', $content);

    if ($content !== $original_content) {
        // Write the modified content back to the file
        file_put_contents($index_path, $content);
        fwrite($log, "Modified index.html\n");
    } else {
        fwrite($log, "No changes needed for index.html\n");
    }

    fwrite($log, "Proxy fix completed at " . date('Y-m-d H:i:s') . "\n");
    fclose($log);

    echo "Proxy fix completed successfully. Check proxy-fix.log for details.";
} else {
    echo "Error: index.html not found at $index_path";
}
?>
