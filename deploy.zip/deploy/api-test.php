<?php
// Simple API test page
header('Content-Type: text/html');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gudang Mitra API Test</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #0066cc;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .endpoint {
            margin-bottom: 20px;
            padding: 15px;
            background-color: #f9f9f9;
            border-left: 4px solid #0066cc;
        }
        .button {
            display: inline-block;
            background-color: #0066cc;
            color: white;
            padding: 8px 15px;
            text-decoration: none;
            border-radius: 4px;
            margin: 5px 0;
            border: none;
            cursor: pointer;
        }
        .button:hover {
            background-color: #0055aa;
        }
        #result {
            margin-top: 20px;
            padding: 15px;
            background-color: #f0f0f0;
            border-radius: 4px;
            white-space: pre-wrap;
            overflow-x: auto;
        }
        .success {
            color: green;
            font-weight: bold;
        }
        .error {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Gudang Mitra API Test</h1>
        
        <p>Use this page to test the API endpoints directly and see the responses.</p>
        
        <div class="endpoint">
            <h3>Login Test</h3>
            <button class="button" onclick="testLogin()">Test Login API</button>
        </div>
        
        <div class="endpoint">
            <h3>Requests Test</h3>
            <button class="button" onclick="testRequests()">Test Requests API</button>
        </div>
        
        <div class="endpoint">
            <h3>Users Test</h3>
            <button class="button" onclick="testUsers()">Test Users API</button>
        </div>
        
        <div class="endpoint">
            <h3>Inventory Test</h3>
            <button class="button" onclick="testInventory()">Test Inventory API</button>
        </div>
        
        <div class="endpoint">
            <h3>Notifications Test</h3>
            <button class="button" onclick="testNotifications()">Test Notifications API</button>
        </div>
        
        <div id="result">Results will appear here...</div>
    </div>
    
    <script>
        // Function to display results
        function displayResult(data, error = false) {
            const resultDiv = document.getElementById('result');
            if (error) {
                resultDiv.innerHTML = `<div class="error">Error: ${JSON.stringify(data, null, 2)}</div>`;
            } else {
                resultDiv.innerHTML = `<div class="success">Success!</div><pre>${JSON.stringify(data, null, 2)}</pre>`;
            }
        }
        
        // Test login API
        async function testLogin() {
            try {
                const response = await fetch('/api/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email: 'admin@gudangmitra.com',
                        password: 'admin123'
                    })
                });
                
                const data = await response.json();
                displayResult(data);
            } catch (error) {
                displayResult(error.message, true);
            }
        }
        
        // Test requests API
        async function testRequests() {
            try {
                const response = await fetch('/db/requests', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        action: 'getAll'
                    })
                });
                
                const data = await response.json();
                displayResult(data);
            } catch (error) {
                displayResult(error.message, true);
            }
        }
        
        // Test users API
        async function testUsers() {
            try {
                const response = await fetch('/db/users', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        action: 'getAll'
                    })
                });
                
                const data = await response.json();
                displayResult(data);
            } catch (error) {
                displayResult(error.message, true);
            }
        }
        
        // Test inventory API
        async function testInventory() {
            try {
                const response = await fetch('/db/inventory', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        action: 'getAll'
                    })
                });
                
                const data = await response.json();
                displayResult(data);
            } catch (error) {
                displayResult(error.message, true);
            }
        }
        
        // Test notifications API
        async function testNotifications() {
            try {
                const response = await fetch('/db/notifications', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        action: 'getAll'
                    })
                });
                
                const data = await response.json();
                displayResult(data);
            } catch (error) {
                displayResult(error.message, true);
            }
        }
    </script>
</body>
</html>
